The **Identity Lifecycle Management - Large Enterprise** pack enables you to provision a maximum of **20k users** from **Workday** into **Active Directory** and **Okta** and perform common HR operations.

For more information, please refer to the **Identity Lifecycle Management - Core** pack and [Identity Lifecycle Management article](https://xsoar.pan.dev/docs/reference/articles/identity-lifecycle-management).
