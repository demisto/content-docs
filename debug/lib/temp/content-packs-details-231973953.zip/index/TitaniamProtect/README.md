# Why This Content Pack?
Titaniam Protect enables you to include the highest level of data security, FIPS 140-2, to your existing Cortex XSOAR deployment. With dynamic encryption from Titaniam, your SOC security controls immediately meet data protection, privacy, segregation of duties, data residency, and least privilege articles in leading regulations including HIPAA, GDPR, CCPA, and ITAR.
Titaniam enables demonstrable and auditable evidence of field level encryption. Sensitive data access is logged and monitored within XSOAR’s native audit logs. Data is released in clear text to only the most privileged users, and dynamically re-encrypted once it has been utilized.
A significant additional benefit is that Cortex XSOAR with Titaniam becomes immune to ransomware related data compromise and extortion, insider threats, and other forms of data breach

# What does the Content Pack do?
Titaniam Protect allows you to protect incident data inside the Cortex XSOAR platform. It delivers two benefits:
1. All sensitive data are encrypted using pre-processing rules. That makes the data store (either BoltDB or Elastic) breach-proof.
2. It privacy-enables Cortex XSOAR. Sensitive data is decrypted and presented in clear text only to those (individuals and playbooks) with appropriate privileges. Rest sees the data only in masked form.

# When does the protection happen?
Titaniam Protect can be set up to protect sensitive fields in an incident
1. As and when an incident is fetched (using pre-processing rule).
2. Or for existing incidents.


# What are the mechanics?
1. Titaniam Protect Content Pack comes with a companion application called Panther, an encryption API service (at no additional cost to the licensee). Customers can define what fields to protect for each SIEM source, in Panther.
2. The content pack plugs in with Cortex XSOAR's built-in and custom roles to provide limited access to decoding of sensitive information.

# How to Install and Use the Content Pack?
Detailed step by step instructions are in the integration readme section.

# Use Cases

## Use Case 1: Fetching incidents from an external system.
Events pulled from an external system, are classified and transformed to incidents at the point of entrance into Cortex XSOAR system. Pre-processing rule can be configured to invoke TitaniamProtectIncident script on incoming incident and apply transformation based on the schema selected based on incident's source brand.
![](https://storage.googleapis.com/marketplace-dist/content/docs/Packs/TitaniamProtect/doc_files/image1.png)


## Use Case 2: Incidents already in the system (encode/protect).
Playbooks and Scripts can be triggered and executed on incidents already present in the system. The same playbook can be scheduled via a Job to run periodically and search for "un-protected" incidents then apply encoding on them based on their source brand and incident type.
![](https://storage.googleapis.com/marketplace-dist/content/docs/Packs/TitaniamProtect/doc_files/image2.png)


## Use Case 3: Incidents already in the system (decode).
Users with specific roles can run decode operation on protected incidents to show sensitive fields in cleartext. Users are provided with custom layout which is associated with "Titaniam Protect" incident type. The layout provides buttons to encode/decode incident data. These buttons are only available to users with specific (Admin/Analyst) roles.
![](https://storage.googleapis.com/marketplace-dist/content/docs/Packs/TitaniamProtect/doc_files/image3.png)


Note: 
1. Incident type does not have to be changed when using the pre-processing rule. Changing incident type might result in some fields removed from the incident.
2. When operating on protected fields that require the field to be in clear text, you will have to decode before the operation.
