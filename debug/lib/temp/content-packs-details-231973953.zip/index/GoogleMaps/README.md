This pack returns the coordinates of a given physical address. 
The location is marked on a map according to the coordinates (lat, lng), or address.
